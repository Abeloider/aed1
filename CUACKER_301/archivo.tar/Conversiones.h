#ifndef CONVERSIONES_H
#define CONVERSIONES_H

#include <string>

using namespace std;

string convertir_num_text(int n);
void convertir_text_num(string& s, int& n);

#endif